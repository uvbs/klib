// Server.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "ServerSocket.h"
#include "ServerSocketHandler.h"

#include <locale>
using namespace std;


////////////////////////////////////////////////////////////////////////////////////
// SocketHandlerImpl
// 
// Purpose:		


class SocketHandlerImpl :
	public SocketHandler
{
	long	i;
public:

	SocketHandlerImpl () : 
		SocketHandler()
	{
		i = -1;
	}


	virtual ~SocketHandlerImpl ()
	{
		SocketHandler::release();
	}

	long run ()
	{
		Socket & sock = getSocket();


		while ( true )
		{

			char buffer[1024];
			long noRead = sock.recieve( buffer, 1024 );

			buffer[noRead] = '\0';


		}
	}
};




////////////////////////////////////////////////////////////////////////////////////
// CreateSocketHandlerImpl
// 
// Purpose:		create connection socket is an abstract class 
//				used only to create connect sockets or their derived classes. 
//				you must implement you own


class CreateSocketHandlerImpl :
	public CreateSocketHandler
{
	long	i;
public:

	CreateSocketHandlerImpl () : 
		CreateSocketHandler()
	{
		i = -1;
	}


	virtual ~CreateSocketHandlerImpl ()
	{}

	// responsible for create a connection
	SocketHandler * createHandler () 
	{
		return (SocketHandler *) new SocketHandlerImpl();
	}

};


char testReq[] =	"GET /menu.html HTTP/1.0\r\n"
					"Host: www.wrox.com\r\n"
					"User-Agent: Lynx/2.7\r\n";


#include "HttpServer.h"
#include "HttpRequestProcess.h"
#include <conio.h>


int main(int argc, char* argv[])
{
	// setup mem check
	#if defined(_DEBUG)
	_CrtSetDbgFlag( _CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF );
	#endif

	// create server
	HttpServer server;
	server.create( string("hubbardd"), string("d:\\Projects\\HtmlMenu\\Menus") );

	// set server links
	HttpResponse::setServer( server );

	while ( true )
	{
		if ( _kbhit() )
			break;

		Sleep(100);
	}



	/*
	// create server
	HttpServerInfo server;
	server.create( string("hubbardd"), string("d:\\Projects\\HtmlMenu\\Menus") );

	// set server links
	HttpResponse::setServer( server );

	// test request processing
	long length = strlen(testReq);

	HttpRequestProcess processReq;
	if ( processReq.process( testReq, length ) )
	{

		string text = "";
		processReq.getString(text);

		long k=0;
		k++;
	}
	*/

	/*

	// init startup
	WSADATA WSAData;
	WSAStartup( MAKEWORD(2,0), &WSAData );

	ServerSocket server(10);
	if ( !server.open( 80 ) )
		return -1;

	// use server handler
	CreateSocketHandlerImpl createSocket;
	ServerSocketHandler	handler(server,(CreateSocketHandler &)createSocket);

	handler.create();

	// handler handles reads so now
	// do nothing
	while ( true )
	{
		Sleep(1000);
	}
	*/


	




	return 0;
}

