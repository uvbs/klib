// SocketTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"

#include "SocketHandler.h"
#include "HttpRequest.h"
#include "HttpResponse.h"



//////////////////////////////////////////////////////////////////////////////
// HttpResonseNotify
//
// Purpose:	process reponses for http requests

class HttpResonseNotify :
	public SocketNotify 
{
	Socket & _socket;
	string   _buffer;

public:

	HttpResonseNotify (Socket & sock) :
		SocketNotify (),
		_socket( sock )
	{}

	// notification method on read
	bool onReceive ( int error )
	{
		// get no of bytes
		long length = _socket.getRecieveSize();
		if ( length == 0 )
		{
			return false;
		}

		// resize buffer if needed
		if ( _buffer.size() < length )
		{
			StringUtil::getBufferString(_buffer,length+1);
		}

		LPTSTR buffer = (LPTSTR) _buffer.data();

		// terminate buffer
		buffer[length] = '\0';

		// recieve 
		length = _socket.recieve( buffer, length );
		if ( length == 0 )
		{
			return false;
		}

		printf("%s",buffer);


		return true;
	}




};


int main(int argc, char* argv[])
{
	
	// init for socket startup		
	WSADATA WSAData;
	WSAStartup( MAKEWORD(2,0), &WSAData );

	// create socket
	Socket sock;
	//if ( !sock.open( string("localhost"), 80 ) )
	if ( !sock.open( string("www.wrox.com"), 80 ) )
		return 0;

	HttpRequest request;
	request.create(idHttpGet);

	string str;
	request.getString(str);

	sock.send( str );

	// use notify handler
	HttpResonseNotify	notify(sock);
	SocketHandler		handler(sock, notify);

	handler.create();

	// handler handles reads so now
	// do nothing
	while ( true )
	{
		Sleep(1000);
	}
	

	return 0;
}

